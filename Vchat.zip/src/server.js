import "dotenv/config";
import express from "express";
import http from "node:http";
import path from "node:path";
import { fileURLToPath } from "node:url";
import helmet from "helmet";
import cors from "cors";
import bcrypt from "bcryptjs";
import crypto from "node:crypto";
import { Server } from "socket.io";
import { pool, query } from "./db.js";
import { requireAuth, signToken, safeUser } from "./auth.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, "..");
const app = express();
const server = http.createServer(app);
const origin = process.env.PUBLIC_ORIGIN || "http://localhost:3000";
const io = new Server(server, { cors: { origin, methods: ["GET", "POST", "PATCH", "DELETE"] } });

app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin, credentials: false }));
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(root, "public")));

const asyncRoute = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const cleanIdentifier = (value) => String(value || "").trim().toLowerCase();
const validUsername = (value) => /^[a-zA-Z0-9_]{3,32}$/.test(String(value || ""));
const publicMessageQuery = `
 SELECT m.id, m.conversation_id, m.sender_id, m.kind, m.body, m.reply_to,
        m.edited_at, m.deleted_at, m.created_at, u.username AS sender_username,
        u.name AS sender_name
 FROM messages m LEFT JOIN users u ON u.id=m.sender_id `;

app.get("/api/health", (req, res) => res.json({ ok: true, service: "Vchat", time: new Date().toISOString() }));

app.post("/api/auth/register", asyncRoute(async (req, res) => {
  const { phone, email, username, password, name } = req.body || {};
  const normalizedEmail = email ? cleanIdentifier(email) : null;
  const normalizedPhone = phone ? String(phone).trim() : null;
  if (!normalizedPhone && !normalizedEmail) return res.status(400).json({ error: "Masukkan nomor HP atau email." });
  if (!validUsername(username)) return res.status(400).json({ error: "Username 3–32 karakter: huruf, angka, dan garis bawah." });
  if (typeof password !== "string" || password.length < 8) return res.status(400).json({ error: "Kata sandi minimal 8 karakter." });
  if (typeof name !== "string" || name.trim().length < 1 || name.trim().length > 80) return res.status(400).json({ error: "Nama wajib diisi (maksimal 80 karakter)." });
  const hash = await bcrypt.hash(password, 12);
  let user;
  try {
    const result = await query(
      `INSERT INTO users(phone,email,username,password_hash,name)
       VALUES($1,$2,$3,$4,$5)
       RETURNING id,phone,email,username,name,bio,birthday,avatar_url,verified,last_seen_at,created_at`,
      [normalizedPhone, normalizedEmail, username.toLowerCase(), hash, name.trim()]
    );
    user = result.rows[0];
  } catch (e) {
    if (e.code === "23505") return res.status(409).json({ error: "Nomor, email, atau username sudah digunakan." });
    throw e;
  }
  const { token, jti } = signToken(user);
  await query("INSERT INTO sessions(user_id,token_jti,device_name,expires_at) VALUES($1,$2,$3,NOW()+INTERVAL '7 days')", [user.id, jti, req.headers["user-agent"] || "Web"]);
  const saved = await query("INSERT INTO conversations(kind,title,created_by) VALUES('saved','Pesan Tersimpan',$1) RETURNING id", [user.id]);
  await query("INSERT INTO conversation_members(conversation_id,user_id,role) VALUES($1,$2,'owner')", [saved.rows[0].id, user.id]);
  res.status(201).json({ user: safeUser(user), token });
}));

app.post("/api/auth/login", asyncRoute(async (req, res) => {
  const identifier = cleanIdentifier(req.body?.identifier);
  const password = req.body?.password;
  if (!identifier || typeof password !== "string") return res.status(400).json({ error: "Identifier dan kata sandi wajib diisi." });
  const result = await query("SELECT * FROM users WHERE lower(email)= $1 OR lower(username)= $1 OR phone=$2 LIMIT 1", [identifier, identifier]);
  if (!result.rowCount || !(await bcrypt.compare(password, result.rows[0].password_hash))) {
    return res.status(401).json({ error: "Login gagal. Periksa data yang dimasukkan." });
  }
  const user = result.rows[0];
  const { token, jti } = signToken(user);
  await query("INSERT INTO sessions(user_id,token_jti,device_name,expires_at) VALUES($1,$2,$3,NOW()+INTERVAL '7 days')", [user.id, jti, req.headers["user-agent"] || "Web"]);
  res.json({ user: safeUser(user), token });
}));

app.post("/api/auth/logout", requireAuth, asyncRoute(async (req, res) => {
  await query("DELETE FROM sessions WHERE token_jti=$1", [req.tokenJti]);
  res.json({ ok: true });
}));

app.post("/api/auth/request-otp", asyncRoute(async (req, res) => {
  const identifier = cleanIdentifier(req.body?.identifier);
  if (identifier.length < 5 || identifier.length > 254) return res.status(400).json({ error: "Nomor HP/email tidak valid." });
  const otp = String(crypto.randomInt(0, 1000000)).padStart(6, "0");
  const codeHash = await bcrypt.hash(otp, 10);
  await query(`INSERT INTO otp_codes(identifier,code_hash,expires_at,attempts)
    VALUES($1,$2,NOW()+($3 || ' minutes')::interval,0)
    ON CONFLICT(identifier) DO UPDATE SET code_hash=EXCLUDED.code_hash, expires_at=EXCLUDED.expires_at, attempts=0, created_at=NOW()`,
    [identifier, codeHash, String(Number(process.env.OTP_TTL_MINUTES || 5))]);
  if (process.env.OTP_DEV_MODE === "true") {
    console.log(`[Vchat DEV OTP] ${identifier}: ${otp}`);
    return res.json({ ok: true, message: "OTP development dibuat. Lihat console server.", ...(process.env.NODE_ENV !== "production" ? { devOtp: otp } : {}) });
  }
  res.status(501).json({ error: "Provider SMS/email belum dikonfigurasi. OTP tidak dikirim." });
}));

app.post("/api/auth/verify-otp", asyncRoute(async (req, res) => {
  const identifier = cleanIdentifier(req.body?.identifier);
  const otp = String(req.body?.otp || "");
  const result = await query("SELECT * FROM otp_codes WHERE identifier=$1 AND expires_at>NOW()", [identifier]);
  if (!result.rowCount || result.rows[0].attempts >= 5) return res.status(400).json({ error: "OTP kedaluwarsa atau tidak tersedia." });
  const match = await bcrypt.compare(otp, result.rows[0].code_hash);
  if (!match) {
    await query("UPDATE otp_codes SET attempts=attempts+1 WHERE identifier=$1", [identifier]);
    return res.status(400).json({ error: "OTP salah." });
  }
  await query("DELETE FROM otp_codes WHERE identifier=$1", [identifier]);
  await query("UPDATE users SET verified=true, updated_at=NOW() WHERE lower(email)=$1 OR phone=$1", [identifier]);
  res.json({ ok: true, message: "OTP valid. Jika akun terdaftar, status verifikasi diperbarui." });
}));

app.get("/api/me", requireAuth, (req, res) => res.json({ user: safeUser(req.user) }));
app.patch("/api/me", requireAuth, asyncRoute(async (req, res) => {
  const { name, username, bio, birthday, avatar_url } = req.body || {};
  if (username !== undefined && !validUsername(username)) return res.status(400).json({ error: "Format username tidak valid." });
  if (name !== undefined && (typeof name !== "string" || !name.trim() || name.length > 80)) return res.status(400).json({ error: "Nama tidak valid." });
  if (bio !== undefined && (typeof bio !== "string" || bio.length > 160)) return res.status(400).json({ error: "Bio maksimal 160 karakter." });
  try {
    const result = await query(
      `UPDATE users SET name=COALESCE($2,name), username=COALESCE($3,username),
       bio=COALESCE($4,bio), birthday=COALESCE($5,birthday), avatar_url=COALESCE($6,avatar_url), updated_at=NOW()
       WHERE id=$1 RETURNING id,phone,email,username,name,bio,birthday,avatar_url,verified,last_seen_at,created_at`,
      [req.user.id, name?.trim(), username?.toLowerCase(), bio, birthday || null, avatar_url]
    );
    res.json({ user: safeUser(result.rows[0]) });
  } catch (e) {
    if (e.code === "23505") return res.status(409).json({ error: "Username sudah dipakai." });
    throw e;
  }
}));

app.get("/api/conversations", requireAuth, asyncRoute(async (req, res) => {
  const result = await query(`
    SELECT c.id,c.kind,c.title,c.photo_url,c.updated_at,cm.pinned,cm.archived,cm.muted,
      COALESCE(c.title, other.name, 'Pesan Tersimpan') AS display_name,
      other.username AS other_username, other.avatar_url AS other_avatar,
      lm.body AS last_message, lm.created_at AS last_message_at,
      (SELECT COUNT(*)::int FROM messages um WHERE um.conversation_id=c.id AND um.sender_id<>$1
       AND um.created_at>COALESCE(cm.last_read_at,'epoch'::timestamptz) AND um.deleted_at IS NULL) AS unread_count
    FROM conversation_members cm
    JOIN conversations c ON c.id=cm.conversation_id
    LEFT JOIN LATERAL (
      SELECT u.name,u.username,u.avatar_url FROM conversation_members cm2
      JOIN users u ON u.id=cm2.user_id
      WHERE cm2.conversation_id=c.id AND cm2.user_id<>$1 LIMIT 1
    ) other ON TRUE
    LEFT JOIN LATERAL (
      SELECT body,created_at FROM messages WHERE conversation_id=c.id AND deleted_at IS NULL
      ORDER BY created_at DESC LIMIT 1
    ) lm ON TRUE
    WHERE cm.user_id=$1 AND cm.archived=false
    ORDER BY cm.pinned DESC, COALESCE(lm.created_at,c.updated_at) DESC
  `, [req.user.id]);
  res.json({ conversations: result.rows });
}));

app.post("/api/conversations", requireAuth, asyncRoute(async (req, res) => {
  const username = cleanIdentifier(req.body?.username).replace(/^@/, "");
  if (!username) return res.status(400).json({ error: "Masukkan username tujuan." });
  const target = await query("SELECT id,username FROM users WHERE username=$1", [username]);
  if (!target.rowCount) return res.status(404).json({ error: "Username tidak ditemukan." });
  if (target.rows[0].id === req.user.id) {
    const saved = await query("SELECT id FROM conversations WHERE kind='saved' AND created_by=$1 LIMIT 1", [req.user.id]);
    if (saved.rowCount) return res.json({ conversationId: saved.rows[0].id });
  }
  const blocked = await query("SELECT 1 FROM blocks WHERE (blocker_id=$1 AND blocked_id=$2) OR (blocker_id=$2 AND blocked_id=$1)", [req.user.id, target.rows[0].id]);
  if (blocked.rowCount) return res.status(403).json({ error: "Percakapan tidak dapat dibuat." });
  const existing = await query(`
    SELECT c.id FROM conversations c
    JOIN conversation_members a ON a.conversation_id=c.id AND a.user_id=$1
    JOIN conversation_members b ON b.conversation_id=c.id AND b.user_id=$2
    WHERE c.kind='direct' LIMIT 1`, [req.user.id, target.rows[0].id]);
  if (existing.rowCount) return res.json({ conversationId: existing.rows[0].id });
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const c = await client.query("INSERT INTO conversations(kind,created_by) VALUES('direct',$1) RETURNING id", [req.user.id]);
    await client.query("INSERT INTO conversation_members(conversation_id,user_id,role) VALUES($1,$2,'owner'),($1,$3,'member')", [c.rows[0].id, req.user.id, target.rows[0].id]);
    await client.query("COMMIT");
    res.status(201).json({ conversationId: c.rows[0].id });
  } catch (e) { await client.query("ROLLBACK"); throw e; }
  finally { client.release(); }
}));

app.get("/api/conversations/:id/messages", requireAuth, asyncRoute(async (req, res) => {
  const membership = await query("SELECT 1 FROM conversation_members WHERE conversation_id=$1 AND user_id=$2", [req.params.id, req.user.id]);
  if (!membership.rowCount) return res.status(403).json({ error: "Bukan anggota percakapan." });
  const before = req.query.before || null;
  const result = await query(`${publicMessageQuery}
    WHERE m.conversation_id=$1 AND m.created_at < COALESCE((SELECT created_at FROM messages WHERE id=$2),NOW())
    ORDER BY m.created_at DESC LIMIT 100`, [req.params.id, before]);
  res.json({ messages: result.rows.reverse() });
}));

async function createMessage({ conversationId, senderId, body, kind = "text", replyTo = null }) {
  const membership = await query("SELECT 1 FROM conversation_members WHERE conversation_id=$1 AND user_id=$2", [conversationId, senderId]);
  if (!membership.rowCount) throw Object.assign(new Error("Bukan anggota percakapan."), { status: 403 });
  const blocked = await query(`SELECT 1 FROM conversation_members mine
    JOIN blocks b ON (b.blocker_id=mine.user_id OR b.blocked_id=mine.user_id)
    WHERE mine.conversation_id=$1 AND mine.user_id=$2 AND
      ((b.blocker_id=$2 AND b.blocked_id<>$2) OR (b.blocked_id=$2 AND b.blocker_id<>$2)) LIMIT 1`, [conversationId, senderId]);
  if (blocked.rowCount) throw Object.assign(new Error("Pesan tidak dapat dikirim."), { status: 403 });
  if (typeof body !== "string" || body.length > 10000 || !body.trim()) throw Object.assign(new Error("Pesan kosong atau terlalu panjang."), { status: 400 });
  const result = await query(`INSERT INTO messages(conversation_id,sender_id,kind,body,reply_to)
    VALUES($1,$2,$3,$4,$5) RETURNING id,conversation_id,sender_id,kind,body,reply_to,created_at`,
    [conversationId, senderId, kind, body.trim(), replyTo]);
  await query("UPDATE conversations SET updated_at=NOW() WHERE id=$1", [conversationId]);
  const msg = await query(`${publicMessageQuery} WHERE m.id=$1`, [result.rows[0].id]);
  return msg.rows[0];
}

app.post("/api/conversations/:id/messages", requireAuth, asyncRoute(async (req, res) => {
  const message = await createMessage({ conversationId: req.params.id, senderId: req.user.id, body: req.body?.body, kind: req.body?.kind, replyTo: req.body?.reply_to });
  io.to(`conversation:${req.params.id}`).emit("message:new", message);
  res.status(201).json({ message });
}));

app.patch("/api/messages/:id", requireAuth, asyncRoute(async (req, res) => {
  const body = req.body?.body;
  if (typeof body !== "string" || !body.trim() || body.length > 10000) return res.status(400).json({ error: "Isi pesan tidak valid." });
  const result = await query(`UPDATE messages SET body=$2,edited_at=NOW()
    WHERE id=$1 AND sender_id=$3 AND deleted_at IS NULL AND created_at>NOW()-INTERVAL '15 minutes'
    RETURNING id,conversation_id,sender_id,body,kind,edited_at,created_at`, [req.params.id, body.trim(), req.user.id]);
  if (!result.rowCount) return res.status(404).json({ error: "Pesan tidak ditemukan atau tidak dapat diedit." });
  io.to(`conversation:${result.rows[0].conversation_id}`).emit("message:updated", result.rows[0]);
  res.json({ message: result.rows[0] });
}));

app.delete("/api/messages/:id", requireAuth, asyncRoute(async (req, res) => {
  const result = await query(`UPDATE messages SET body='',deleted_at=NOW()
    WHERE id=$1 AND sender_id=$2 AND deleted_at IS NULL RETURNING id,conversation_id`, [req.params.id, req.user.id]);
  if (!result.rowCount) return res.status(404).json({ error: "Pesan tidak ditemukan." });
  io.to(`conversation:${result.rows[0].conversation_id}`).emit("message:deleted", { id: result.rows[0].id });
  res.json({ ok: true });
}));

app.post("/api/conversations/:id/read", requireAuth, asyncRoute(async (req, res) => {
  const member = await query("UPDATE conversation_members SET last_read_at=NOW() WHERE conversation_id=$1 AND user_id=$2 RETURNING conversation_id", [req.params.id, req.user.id]);
  if (!member.rowCount) return res.status(403).json({ error: "Bukan anggota percakapan." });
  io.to(`conversation:${req.params.id}`).emit("message:read", { conversationId: req.params.id, userId: req.user.id, at: new Date().toISOString() });
  res.json({ ok: true });
}));

app.get("/api/contacts", requireAuth, asyncRoute(async (req, res) => {
  const result = await query(`SELECT u.id,u.name,u.username,u.phone,u.avatar_url,u.bio,u.last_seen_at,c.display_name
    FROM contacts c JOIN users u ON u.id=c.contact_user_id WHERE c.owner_id=$1 AND c.hidden=false ORDER BY COALESCE(c.display_name,u.name)`, [req.user.id]);
  res.json({ contacts: result.rows });
}));

app.post("/api/contacts", requireAuth, asyncRoute(async (req, res) => {
  const username = cleanIdentifier(req.body?.username).replace(/^@/, "");
  const displayName = String(req.body?.display_name || "").trim().slice(0, 80) || null;
  const target = await query("SELECT id FROM users WHERE username=$1", [username]);
  if (!target.rowCount) return res.status(404).json({ error: "Username tidak ditemukan." });
  if (target.rows[0].id === req.user.id) return res.status(400).json({ error: "Tidak dapat menambahkan akun sendiri." });
  await query(`INSERT INTO contacts(owner_id,contact_user_id,display_name) VALUES($1,$2,$3)
    ON CONFLICT(owner_id,contact_user_id) DO UPDATE SET display_name=EXCLUDED.display_name`, [req.user.id, target.rows[0].id, displayName]);
  res.status(201).json({ ok: true });
}));

app.post("/api/blocks/:userId", requireAuth, asyncRoute(async (req, res) => {
  if (req.params.userId === req.user.id) return res.status(400).json({ error: "Tidak dapat memblokir diri sendiri." });
  await query("INSERT INTO blocks(blocker_id,blocked_id) VALUES($1,$2) ON CONFLICT DO NOTHING", [req.user.id, req.params.userId]);
  res.json({ ok: true });
}));
app.delete("/api/blocks/:userId", requireAuth, asyncRoute(async (req, res) => {
  await query("DELETE FROM blocks WHERE blocker_id=$1 AND blocked_id=$2", [req.user.id, req.params.userId]);
  res.json({ ok: true });
}));
app.get("/api/blocks", requireAuth, asyncRoute(async (req, res) => {
  const result = await query("SELECT u.id,u.name,u.username FROM blocks b JOIN users u ON u.id=b.blocked_id WHERE b.blocker_id=$1 ORDER BY b.created_at DESC", [req.user.id]);
  res.json({ blocked: result.rows });
}));

io.use(async (socket, next) => {
  try {
    const token = socket.handshake.auth?.token;
    if (!token) return next(new Error("Unauthorized"));
    const jwt = await import("jsonwebtoken");
    const payload = jwt.default.verify(token, process.env.JWT_SECRET, { issuer: "vchat" });
    const valid = await query("SELECT 1 FROM sessions WHERE token_jti=$1 AND user_id=$2 AND expires_at>NOW()", [payload.jti, payload.sub]);
    if (!valid.rowCount) return next(new Error("Unauthorized"));
    socket.userId = payload.sub;
    socket.username = payload.username;
    next();
  } catch { next(new Error("Unauthorized")); }
});

const onlineUsers = new Map();
io.on("connection", (socket) => {
  onlineUsers.set(socket.userId, (onlineUsers.get(socket.userId) || 0) + 1);
  io.emit("presence:update", { userId: socket.userId, username: socket.username, online: true });
  socket.on("conversation:join", async (conversationId) => {
    if (typeof conversationId !== "string") return;
    const member = await query("SELECT 1 FROM conversation_members WHERE conversation_id=$1 AND user_id=$2", [conversationId, socket.userId]);
    if (member.rowCount) socket.join(`conversation:${conversationId}`);
  });
  socket.on("message:send", async (payload, callback) => {
    try {
      const message = await createMessage({ conversationId: payload?.conversationId, senderId: socket.userId, body: payload?.body, kind: payload?.kind, replyTo: payload?.reply_to });
      io.to(`conversation:${payload.conversationId}`).emit("message:new", message);
      if (typeof callback === "function") callback({ ok: true, message });
    } catch (e) { if (typeof callback === "function") callback({ ok: false, error: e.message }); }
  });
  socket.on("typing:start", async (conversationId) => {
    const member = await query("SELECT 1 FROM conversation_members WHERE conversation_id=$1 AND user_id=$2", [conversationId, socket.userId]);
    if (member.rowCount) socket.to(`conversation:${conversationId}`).emit("typing:update", { conversationId, userId: socket.userId, username: socket.username, typing: true });
  });
  socket.on("typing:stop", (conversationId) => socket.to(`conversation:${conversationId}`).emit("typing:update", { conversationId, userId: socket.userId, typing: false }));
  socket.on("disconnect", async () => {
    const count = (onlineUsers.get(socket.userId) || 1) - 1;
    if (count <= 0) {
      onlineUsers.delete(socket.userId);
      await query("UPDATE users SET last_seen_at=NOW() WHERE id=$1", [socket.userId]).catch(() => {});
      io.emit("presence:update", { userId: socket.userId, username: socket.username, online: false });
    } else onlineUsers.set(socket.userId, count);
  });
});

app.use("/api", (err, req, res, next) => {
  console.error(err);
  if (res.headersSent) return next(err);
  res.status(err.status || 500).json({ error: err.status ? err.message : "Terjadi kesalahan server." });
});
app.get("*", (req, res) => res.sendFile(path.join(root, "public", "index.html")));

const port = Number(process.env.PORT || 3000);
server.listen(port, () => console.log(`Vchat running at http://localhost:${port}`));
process.on("SIGINT", async () => { await pool.end(); process.exit(0); });
