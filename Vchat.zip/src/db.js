import pg from "pg";
import dotenv from "dotenv";
dotenv.config();

const { Pool } = pg;
export const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_SSL === "true" ? { rejectUnauthorized: false } : undefined
});

pool.on("error", (err) => console.error("Unexpected PostgreSQL pool error:", err.message));
export async function query(text, params = []) {
  return pool.query(text, params);
}
