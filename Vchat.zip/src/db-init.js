import fs from "node:fs/promises";
import { pool } from "./db.js";

try {
  const sql = await fs.readFile(new URL("./schema.sql", import.meta.url), "utf8");
  await pool.query(sql);
  console.log("Vchat database schema initialized.");
} catch (err) {
  console.error("Database initialization failed:", err.message);
  process.exitCode = 1;
} finally {
  await pool.end();
}
