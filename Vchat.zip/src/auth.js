import jwt from "jsonwebtoken";
import crypto from "node:crypto";
import { query } from "./db.js";

const secret = () => {
  const value = process.env.JWT_SECRET;
  if (!value || value.length < 32) throw new Error("JWT_SECRET must be at least 32 characters.");
  return value;
};

export function signToken(user, jti = crypto.randomUUID()) {
  const token = jwt.sign({ sub: user.id, username: user.username, jti }, secret(), { expiresIn: "7d", issuer: "vchat" });
  return { token, jti };
}

export async function requireAuth(req, res, next) {
  try {
    const header = req.headers.authorization || "";
    const token = header.startsWith("Bearer ") ? header.slice(7) : "";
    if (!token) return res.status(401).json({ error: "Silakan login terlebih dahulu." });
    const payload = jwt.verify(token, secret(), { issuer: "vchat" });
    const session = await query(
      "SELECT s.id FROM sessions s WHERE s.token_jti=$1 AND s.user_id=$2 AND s.expires_at > NOW()",
      [payload.jti, payload.sub]
    );
    if (!session.rowCount) return res.status(401).json({ error: "Sesi tidak aktif. Silakan login ulang." });
    const result = await query("SELECT id, phone, email, username, name, bio, birthday, avatar_url, verified, last_seen_at, created_at FROM users WHERE id=$1", [payload.sub]);
    if (!result.rowCount) return res.status(401).json({ error: "Akun tidak ditemukan." });
    req.user = result.rows[0];
    req.tokenJti = payload.jti;
    next();
  } catch {
    return res.status(401).json({ error: "Token tidak valid atau kedaluwarsa." });
  }
}

export function safeUser(user) {
  return {
    id: user.id, phone: user.phone, email: user.email, username: user.username,
    name: user.name, bio: user.bio, birthday: user.birthday,
    avatar_url: user.avatar_url, verified: user.verified,
    last_seen_at: user.last_seen_at, created_at: user.created_at
  };
}
