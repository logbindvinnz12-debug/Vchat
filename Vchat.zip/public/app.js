const $ = (selector) => document.querySelector(selector);
const state = {
  token: localStorage.getItem("vchat_token") || "",
  user: null, conversations: [], active: null, messages: [], socket: null,
  view: "chats", filter: "all", query: "", typing: new Map(), contacts: []
};
const initials = (name = "V") => name.trim().split(/\s+/).slice(0,2).map(x => x[0] || "").join("").toUpperCase();
const escapeHtml = (value = "") => String(value).replace(/[&<>"']/g, ch => ({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;" }[ch]));
const timeLabel = (value) => {
  if (!value) return "";
  const d = new Date(value), now = new Date();
  return d.toDateString() === now.toDateString() ? d.toLocaleTimeString("id-ID",{hour:"2-digit",minute:"2-digit"}) : d.toLocaleDateString("id-ID",{day:"2-digit",month:"short"});
};
function toast(message) {
  const el = $("#toast"); el.textContent = message; el.classList.add("show");
  clearTimeout(toast.timer); toast.timer = setTimeout(() => el.classList.remove("show"), 2600);
}
async function api(path, options = {}) {
  const headers = { "Content-Type":"application/json", ...(state.token ? { Authorization:`Bearer ${state.token}` } : {}), ...(options.headers || {}) };
  const response = await fetch(path, { ...options, headers });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    if (response.status === 401 && state.token) logout(false);
    throw new Error(data.error || "Permintaan gagal.");
  }
  return data;
}
function showModal(title, description, body, submitLabel, onSubmit, footer = "") {
  const root = $("#modal-root");
  root.innerHTML = `<div class="modal-backdrop"><section class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><h2 id="modal-title">${escapeHtml(title)}</h2><p>${escapeHtml(description || "")}</p><form id="modal-form">${body}<div class="modal-actions"><button type="button" class="secondary-button" id="modal-cancel">Batal</button><button type="submit" class="primary-button">${escapeHtml(submitLabel || "Simpan")}</button></div></form>${footer}</section></div>`;
  const close = () => root.innerHTML = "";
  $("#modal-cancel").onclick = close;
  root.querySelector(".modal-backdrop").addEventListener("click", e => { if (e.target.classList.contains("modal-backdrop")) close(); });
  $("#modal-form").onsubmit = async e => { e.preventDefault(); const btn = e.submitter; btn.disabled = true; try { await onSubmit(new FormData(e.currentTarget), close); } catch (err) { toast(err.message); btn.disabled = false; } };
  return { close, root };
}
function authModal(mode = "login") {
  const isRegister = mode === "register";
  const body = `${isRegister ? `<div class="form-field"><label>Nama tampilan</label><input name="name" maxlength="80" required placeholder="Nama Anda"></div><div class="form-field"><label>Username unik</label><input name="username" pattern="[A-Za-z0-9_]{3,32}" maxlength="32" required placeholder="vienxor"><small style="color:var(--muted)">Huruf, angka, garis bawah. Tanpa @.</small></div>` : ""}
    <div class="form-field"><label>Nomor HP atau email</label><input name="identifier" required autocomplete="username" placeholder="nama@email.com atau nomor HP"></div>
    ${isRegister ? `<div class="form-field"><label>Metode akun</label><select name="kind"><option value="email">Email</option><option value="phone">Nomor HP</option></select></div>` : ""}
    <div class="form-field"><label>Kata sandi (minimal 8 karakter)</label><input name="password" type="password" minlength="8" required autocomplete="${isRegister ? "new-password":"current-password"}"></div>`;
  showModal(isRegister ? "Buat akun Vchat" : "Masuk ke Vchat", isRegister ? "Buat identitas Vchat dengan username unik." : "Masuk menggunakan email, nomor HP, atau username dan kata sandi.", body, isRegister ? "Daftar" : "Masuk", async (form, close) => {
    const identifier = String(form.get("identifier")).trim();
    let payload;
    if (isRegister) {
      const kind = form.get("kind");
      payload = { name:form.get("name"), username:form.get("username"), password:form.get("password"), ...(kind === "email" ? { email:identifier } : { phone:identifier }) };
    } else payload = { identifier, password:form.get("password") };
    const data = await api(isRegister ? "/api/auth/register" : "/api/auth/login", { method:"POST", body:JSON.stringify(payload) });
    state.token = data.token; state.user = data.user; localStorage.setItem("vchat_token", state.token); close();
    await bootApp();
  }, `<button class="modal-link" id="switch-auth">${isRegister ? "Sudah punya akun? Masuk" : "Belum punya akun? Daftar"}</button>`);
  $("#switch-auth").onclick = () => authModal(isRegister ? "login" : "register");
}
function renderProfile() {
  $("#my-name").textContent = state.user?.name || "Akun Vchat";
  $("#my-username").textContent = state.user ? `@${state.user.username}` : "@username";
}
function renderList() {
  const list = $("#chat-list");
  if (state.view !== "chats") {
    const title = state.view === "status" ? "Status kontak" : "Riwayat panggilan";
    list.innerHTML = `<div class="empty-state">${title}<br><br>${state.view === "status" ? "Status 24 jam akan muncul di sini saat fitur status diaktifkan." : "Riwayat panggilan akan muncul di sini saat panggilan WebRTC diintegrasikan."}</div>`;
    return;
  }
  let rows = state.conversations.filter(c => {
    const query = state.query.toLowerCase();
    const matchQuery = !query || `${c.display_name||""} ${c.other_username||""} ${c.last_message||""}`.toLowerCase().includes(query);
    const matchFilter = state.filter === "all" || (state.filter === "unread" && Number(c.unread_count)>0) || (state.filter === "pinned" && c.pinned);
    return matchQuery && matchFilter;
  });
  if (!rows.length) {
    list.innerHTML = `<div class="empty-state">${state.query ? "Tidak ada hasil pencarian." : "Belum ada percakapan.<br><br>Tekan ＋ untuk memulai chat baru."}</div>`;
    return;
  }
  list.innerHTML = rows.map(c => `<button class="chat-item ${state.active?.id===c.id?"active":""}" data-id="${c.id}">
    <div class="avatar">${c.other_avatar ? `<img src="${escapeHtml(c.other_avatar)}" alt="">` : escapeHtml(initials(c.display_name))}</div>
    <div class="chat-meta"><div class="chat-line"><b>${escapeHtml(c.display_name || "Percakapan")}</b><span class="chat-time">${timeLabel(c.last_message_at || c.updated_at)}</span></div>
    <div class="chat-preview"><span>${c.last_message ? escapeHtml(c.last_message) : (c.other_username ? `@${escapeHtml(c.other_username)}` : "Mulai percakapan")}</span>${Number(c.unread_count)>0 ? `<span class="unread">${c.unread_count}</span>` : ""}</div></div></button>`).join("");
  list.querySelectorAll(".chat-item").forEach(el => el.onclick = () => openConversation(el.dataset.id));
}
function renderMessages() {
  const container = $("#messages");
  if (!state.messages.length) { container.innerHTML = `<div class="empty-state">Belum ada pesan. Mulai percakapan.</div>`; return; }
  container.innerHTML = state.messages.map(m => {
    const mine = m.sender_id === state.user?.id;
    const deleted = Boolean(m.deleted_at) || m.body === "";
    return `<article class="message-row ${mine?"mine":""}" data-message-id="${m.id}">
      <div class="message-bubble">${!mine ? `<div class="message-sender">${escapeHtml(m.sender_name || m.sender_username || "Pengguna")}</div>` : ""}${deleted ? `<i>Pesan dihapus</i>` : escapeHtml(m.body)} </div>
      <div class="message-foot"><span>${timeLabel(m.created_at)}</span>${m.edited_at ? `<span class="edited">diedit</span>` : ""}${mine ? `<span aria-label="terkirim">✓✓</span>` : ""}</div>
    </article>`;
  }).join("");
  container.scrollTop = container.scrollHeight;
}
function setActiveView(view) {
  state.view = view;
  document.querySelectorAll("[data-view]").forEach(el => el.classList.toggle("active", el.dataset.view === view));
  renderList();
}
async function refreshConversations() {
  const data = await api("/api/conversations");
  state.conversations = data.conversations || [];
  renderList();
}
async function openConversation(id) {
  const conversation = state.conversations.find(c => c.id === id);
  if (!conversation) return;
  state.active = conversation;
  $("#welcome").classList.add("hidden"); $("#chat-view").classList.remove("hidden");
  $("#chat-title").textContent = conversation.display_name || "Percakapan";
  $("#chat-avatar").textContent = initials(conversation.display_name || "V");
  $("#chat-presence").textContent = conversation.other_username ? `@${conversation.other_username}` : "Percakapan pribadi";
  $("#pinned-strip").classList.add("hidden");
  document.querySelectorAll(".chat-item").forEach(el => el.classList.toggle("active", el.dataset.id === id));
  document.querySelector(".app").classList.add("mobile-chat");
  state.socket?.emit("conversation:join", id);
  const data = await api(`/api/conversations/${id}/messages`);
  state.messages = data.messages || [];
  renderMessages();
  await api(`/api/conversations/${id}/read`, { method:"POST", body:"{}" }).catch(() => {});
  refreshConversations().catch(() => {});
  $("#message-input").focus();
}
async function sendMessage(body) {
  if (!state.active || !body.trim()) return;
  const message = body.trim();
  $("#message-input").value = "";
  try {
    if (state.socket?.connected) {
      state.socket.emit("message:send", { conversationId:state.active.id, body:message, kind:"text" }, result => {
        if (!result?.ok) toast(result?.error || "Pesan gagal dikirim.");
      });
    } else {
      const data = await api(`/api/conversations/${state.active.id}/messages`, { method:"POST", body:JSON.stringify({ body:message, kind:"text" }) });
      addMessage(data.message);
    }
    refreshConversations().catch(() => {});
  } catch (e) { $("#message-input").value = message; toast(e.message); }
}
function addMessage(message) {
  if (!message?.id) return;
  if (state.active?.id === message.conversation_id && !state.messages.some(m => m.id === message.id)) {
    state.messages.push(message); renderMessages();
  }
  const c = state.conversations.find(c => c.id === message.conversation_id);
  if (c) { c.last_message = message.body; c.last_message_at = message.created_at; }
  renderList();
}
function connectSocket() {
  if (state.socket) state.socket.disconnect();
  if (typeof io !== "function") return;
  state.socket = io({ auth:{ token:state.token } });
  state.socket.on("connect_error", () => {});
  state.socket.on("message:new", addMessage);
  state.socket.on("message:updated", updated => {
    const i = state.messages.findIndex(m => m.id === updated.id);
    if (i >= 0) { state.messages[i] = { ...state.messages[i], ...updated }; renderMessages(); }
    refreshConversations().catch(() => {});
  });
  state.socket.on("message:deleted", ({id}) => {
    const m = state.messages.find(m => m.id === id);
    if (m) { m.body = ""; m.deleted_at = new Date().toISOString(); renderMessages(); }
  });
  state.socket.on("typing:update", data => {
    if (data.conversationId !== state.active?.id) return;
    $("#typing-line").classList.toggle("hidden", !data.typing);
    $("#typing-line").textContent = data.typing ? `${data.username || "Kontak"} sedang mengetik…` : "";
  });
  state.socket.on("presence:update", data => {
    if (state.active?.other_username === data.username) $("#chat-presence").textContent = data.online ? "Online" : "Terakhir dilihat baru-baru ini";
  });
}
async function bootApp() {
  try {
    if (!state.user) state.user = (await api("/api/me")).user;
    $("#splash").classList.add("hidden"); $("#app").classList.remove("hidden");
    renderProfile(); connectSocket(); await refreshConversations();
  } catch (e) {
    localStorage.removeItem("vchat_token"); state.token = ""; state.user = null;
    $("#splash").classList.add("hidden"); $("#app").classList.remove("hidden");
    renderProfile(); authModal("login");
  }
}
async function logout(showMessage = true) {
  try { if (state.token) await api("/api/auth/logout",{method:"POST",body:"{}"}); } catch {}
  state.socket?.disconnect(); state.token = ""; state.user = null; state.active = null;
  localStorage.removeItem("vchat_token");
  if (showMessage) toast("Anda telah keluar.");
  authModal("login");
}
function newChatModal() {
  showModal("Obrolan baru", "Cari pengguna menggunakan username unik Vchat.", `<div class="form-field"><label>Username tujuan</label><input name="username" required placeholder="@vienxor" pattern="@?[A-Za-z0-9_]{3,32}"></div>`, "Buka chat", async (form, close) => {
    const username = String(form.get("username")).replace(/^@/,"");
    const data = await api("/api/conversations",{method:"POST",body:JSON.stringify({username})});
    close(); await refreshConversations(); await openConversation(data.conversationId);
  });
}
function profileModal() {
  showModal("Profil Anda", "Username Anda harus unik. Perubahan disimpan ke server.", `
    <div class="form-field"><label>Nama tampilan</label><input name="name" required maxlength="80" value="${escapeHtml(state.user.name)}"></div>
    <div class="form-field"><label>Username</label><input name="username" required pattern="[A-Za-z0-9_]{3,32}" maxlength="32" value="${escapeHtml(state.user.username)}"></div>
    <div class="form-field"><label>Bio</label><textarea name="bio" maxlength="160">${escapeHtml(state.user.bio||"")}</textarea></div>
    <div class="form-field"><label>Tanggal lahir</label><input name="birthday" type="date" value="${state.user.birthday ? String(state.user.birthday).slice(0,10):""}"></div>
    <div class="form-field"><label>URL foto profil (opsional)</label><input name="avatar_url" type="url" placeholder="https://…" value="${escapeHtml(state.user.avatar_url||"")}"></div>`,
    "Simpan profil", async (form, close) => {
      const payload = {name:form.get("name"),username:form.get("username"),bio:form.get("bio"),birthday:form.get("birthday")||null,avatar_url:form.get("avatar_url")||null};
      const data = await api("/api/me",{method:"PATCH",body:JSON.stringify(payload)});
      state.user = data.user; close(); renderProfile(); toast("Profil diperbarui.");
    }, `<button class="modal-link" id="logout-button">Keluar dari akun</button>`);
  $("#logout-button").onclick = () => { $("#modal-root").innerHTML=""; logout(); };
}
function menuModal() {
  const root = $("#modal-root");
  root.innerHTML = `<div class="modal-backdrop"><section class="modal" role="dialog" aria-modal="true"><h2>Menu Vchat</h2><p>Pengaturan akun dan aplikasi</p><div class="menu-list">
  <button id="menu-profile">Profil dan username</button><button id="menu-theme">Ganti mode terang/gelap</button><button id="menu-contacts">Tambah kontak dengan username</button><button id="menu-blocks">Daftar blokir</button><button id="menu-about">Tentang Vchat</button><button id="menu-close">Tutup</button></div></section></div>`;
  const close = () => root.innerHTML = "";
  $("#menu-close").onclick = close;
  $("#menu-profile").onclick = () => { close(); profileModal(); };
  $("#menu-theme").onclick = () => { close(); toggleTheme(); };
  $("#menu-contacts").onclick = () => { close(); contactModal(); };
  $("#menu-blocks").onclick = () => { close(); blocksModal(); };
  $("#menu-about").onclick = () => { close(); showModal("Tentang Vchat","Vchat adalah aplikasi pesan berbasis web yang sedang dikembangkan.",`<p style="margin:0">Versi 1.0.0 · Tema biru #165DFF<br>Backend Node.js · PostgreSQL · Socket.IO</p>`,"Selesai",(_,done)=>done()); };
}
function contactModal() {
  showModal("Tambah kontak", "Tambahkan pengguna Vchat melalui username.", `<div class="form-field"><label>Username</label><input name="username" required placeholder="@nama"></div><div class="form-field"><label>Nama kontak (opsional)</label><input name="display_name" maxlength="80" placeholder="Nama panggilan"></div>`, "Tambah", async (form, close) => {
    await api("/api/contacts",{method:"POST",body:JSON.stringify({username:String(form.get("username")).replace(/^@/,""),display_name:form.get("display_name")})});
    close(); toast("Kontak ditambahkan.");
  });
}
async function blocksModal() {
  const data = await api("/api/blocks");
  const content = data.blocked.length ? data.blocked.map(u=>`<p style="margin:8px 0">@${escapeHtml(u.username)} · ${escapeHtml(u.name)}</p>`).join("") : `<p style="margin:0">Belum ada kontak yang diblokir.</p>`;
  showModal("Daftar blokir","Kelola akun yang diblokir.",content,"Selesai",(_,close)=>close());
}
function toggleTheme() {
  const next = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
  document.documentElement.dataset.theme = next; localStorage.setItem("vchat_theme",next);
  $("#theme-button").textContent = next === "dark" ? "☾" : "☼";
}
function showChatSearch() {
  showModal("Cari pesan", "Pencarian lokal pada pesan yang sudah dimuat.", `<div class="form-field"><label>Kata kunci</label><input name="query" required placeholder="Cari teks pesan…"></div>`, "Cari", async (form,close) => {
    const q = String(form.get("query")).toLowerCase();
    const hits = state.messages.filter(m=>m.body?.toLowerCase().includes(q));
    close();
    if (!hits.length) return toast("Tidak ada pesan yang cocok.");
    const first = hits[0]; const el = document.querySelector(`[data-message-id="${first.id}"]`);
    el?.scrollIntoView({behavior:"smooth",block:"center"}); el?.animate([{outline:"2px solid var(--blue)"},{outline:"2px solid transparent"}],{duration:1300});
    toast(`${hits.length} pesan ditemukan.`);
  });
}
document.addEventListener("DOMContentLoaded", () => {
  const theme = localStorage.getItem("vchat_theme") || (matchMedia("(prefers-color-scheme: dark)").matches ? "dark":"light");
  document.documentElement.dataset.theme = theme;
  $("#theme-button").textContent = theme === "dark" ? "☾" : "☼";
  setTimeout(() => { $("#splash").classList.add("hidden"); $("#app").classList.remove("hidden"); }, 450);
  if (state.token) bootApp(); else authModal("login");
  $("#new-chat").onclick = newChatModal; $("#welcome-new").onclick = newChatModal;
  $("#menu-button").onclick = menuModal; $("#profile-button").onclick = profileModal;
  $("#theme-button").onclick = toggleTheme; $("#chat-search-button").onclick = showChatSearch;
  $("#chat-menu-button").onclick = () => showModal("Opsi percakapan","Aksi dasar untuk percakapan ini.",`<div class="menu-list"><button type="button" id="chat-refresh">Muat ulang pesan</button><button type="button" id="chat-copy">Salin username</button></div>`, "Tutup",(_,close)=>close());
  $("#chat-menu-button").addEventListener("click",()=>setTimeout(()=>{
    $("#chat-refresh")?.addEventListener("click",async()=>{const id=state.active?.id;if(id){const d=await api(`/api/conversations/${id}/messages`);state.messages=d.messages;renderMessages();}$("#modal-root").innerHTML="";});
    $("#chat-copy")?.addEventListener("click",async()=>{if(state.active?.other_username)await navigator.clipboard?.writeText("@"+state.active.other_username);$("#modal-root").innerHTML="";toast("Username disalin jika clipboard diizinkan.");});
  },0));
  $("#back-button").onclick = () => $(".app").classList.remove("mobile-chat");
  $("#search").oninput = e => { state.query=e.target.value; renderList(); };
  document.querySelectorAll(".filter").forEach(el=>el.onclick=()=>{state.filter=el.dataset.filter;document.querySelectorAll(".filter").forEach(b=>b.classList.toggle("active",b===el));renderList();});
  document.querySelectorAll("[data-view]").forEach(el=>el.onclick=()=>setActiveView(el.dataset.view));
  $("#composer").onsubmit = e => { e.preventDefault(); sendMessage($("#message-input").value); };
  $("#message-input").addEventListener("input", () => { if(state.active)state.socket?.emit("typing:start",state.active.id); clearTimeout(window.typingTimeout); window.typingTimeout=setTimeout(()=>{if(state.active)state.socket?.emit("typing:stop",state.active.id);},800); });
  $("#emoji-button").onclick = () => { const input=$("#message-input");input.value += " 🙂";input.focus(); };
  $("#attach-button").onclick = () => toast("Lampiran media membutuhkan modul upload yang aman.");
  if ("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js").catch(()=>{});
});
